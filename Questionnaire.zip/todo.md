- role staff 
- permission
- users managment
- offers

-test develop 
- use lumen api