@extends('layouts.base')

@section('body')
    @yield('content')
@endsection
