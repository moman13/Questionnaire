<tr class="bg-white">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Delegates
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates"  type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-gray-50">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Customers
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-white">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Questions
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-gray-50">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Documents
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-white">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        User
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-gray-50">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Roles
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-white">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Role
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-gray-50">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Aria
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-white">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        City
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>
<tr class="bg-gray-50">
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">
        Settings
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">View</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Add</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Edit</label>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">Delete</label>
            </div>
        </div>

    </td>
    <td class="px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900">

        <div class="flex items-start">
            <div class="absolute flex items-center h-5">
                <input id="candidates" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
            </div>
            <div class="pl-7 text-sm leading-5">
                <label for="candidates" class="font-medium text-gray-700">All</label>
            </div>
        </div>

    </td>

</tr>