<div>
    {{-- The Master doesn't talk, he acts. --}}
</div>
