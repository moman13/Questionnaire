<div>
    @if($status ==1)
        <x-alert.confirm />
    @endif
    @if($status ==2)
        <x-alert.success />
    @endif
</div>
