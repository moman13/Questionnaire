require('./bootstrap');

var Turbolinks = require("turbolinks")
Turbolinks.start()
// var Vue = require('vue');
//
// new Vue({
//     el: '#app'
// });