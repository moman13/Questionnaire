1) package for create Crud staff from command is just create index page and form 
and connect him for model 

2) you can do something lik this is: 
- create route 
- create livewire staff and add some defualt funcation on it 
- add blade  and set up ready to go as table search and order colums
- connect all tables and form to it 


# Another Thoughts 

- create component package to use 
- create function in livewire same as laravel controller
- create dataTable in livewire 