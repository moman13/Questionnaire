<div class=" px-4 py-2 max-w-7xl mx-auto px-4 sm:px-6 md:px-8  mb-2 flex flex-row-reverse">
    <span class="inline-flex rounded-md shadow-sm">

    </span>
</div>
<div class="container  mx-auto flex  max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
    <div class="border border-gray-300 p-6 w-full  bg-white shadow-lg rounded-lg">
        <div class="flex-col">

            <form class="w-full" <?php if($status ==3): ?> wire:submit.prevent="update" <?php else: ?>  wire:submit.prevent="save" <?php endif; ?>>
                <div class="md:flex  md:flex-no-wrap -mx-3 mb-6">
                    <div class="w-1.5/5 md:w-1.5/5 sm:w-auto flex-none px-3 mb-6 md:mb-0">
                        <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">
                            Name (en)
                        </label>
                        <input autocomplete='false' wire:model="form.name_en" class="appearance-none block sm:w-full bg-gray-200 text-gray-700 border  rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-first-name" type="text" placeholder="Jane">

                    </div>
                    <div class="w-1.5/5 md:w-1.5/5 sm:w-auto flex-none px-3 mb-6 md:mb-0">
                        <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="grid-first-name">
                            Name (ar)
                        </label>
                        <input autocomplete='false' wire:model="form.name_ar" class="appearance-none block sm:w-full bg-gray-200 text-gray-700 border  rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white" id="grid-first-name" type="text" placeholder="المدينة">

                    </div>
                    <div class="w-2/5  md:w-2/5  sm:w-auto   flex-none px-3 mb-6 md:mb-0">
                        <label class="block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2" for="location">
                            City
                        </label>
                        <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('car-model-select', ['wire:model' => 'form.city_id','name' => 'selected_value','value' => $select_value])->dom;
} elseif ($_instance->childHasBeenRendered('dEUhgow')) {
    $componentId = $_instance->getRenderedChildComponentId('dEUhgow');
    $componentTag = $_instance->getRenderedChildComponentTagName('dEUhgow');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dEUhgow');
} else {
    $response = \Livewire\Livewire::mount('car-model-select', ['wire:model' => 'form.city_id','name' => 'selected_value','value' => $select_value]);
    $dom = $response->dom;
    $_instance->logRenderedChild('dEUhgow', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
                        
                        
                        
                        
                        
                        
                    </div>
                </div>
                <div class="w-full  text-right   w-auto m-auto flex-none px-3">

                    <button style="
    padding: 15px;
    margin-top: 10px;
" class="rounded-lg px-4 md:px-5 xl:px-4 py-3 md:py-4 xl:py-3 bg-teal-500 hover:bg-teal-600 md:text-lg xl:text-base text-white font-semibold leading-tight shadow-md"><?php echo e($button_type); ?></button>
                </div>
            </form>


        </div>
    </div>
</div><?php /**PATH C:\wamp64\www\Questionnaire\resources\views/admin/regins/form.blade.php ENDPATH**/ ?>