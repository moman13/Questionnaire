<div
        x-data
        x-init="FilePond.setOptions({
            server:{
                process:(fieldName,file,metadata,load,error,progress,abort,transfer,options)=>{
                    window.livewire.find('<?php echo e($_instance->id); ?>').upload('file',file,load,error,progress)
                },
                revert:()=>{
                    window.livewire.find('<?php echo e($_instance->id); ?>').removeUpload('file',filename,load)
                }
            },

        });
        FilePond.create($refs.input);
    "
        wire:ignore>
    <input type="file" x-ref="input">
</div><?php /**PATH C:\wamp64\www\Questionnaire\resources\views/components/filepon.blade.php ENDPATH**/ ?>