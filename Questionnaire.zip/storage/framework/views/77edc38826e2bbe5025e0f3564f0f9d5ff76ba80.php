<tr class="bg-white">
    <td   <?php echo e($attributes); ?>  class=" text-center px-6 py-4 whitespace-no-wrap text-sm leading-5 font-medium text-gray-900"  >No Data </td>
</tr><?php /**PATH C:\wamp64\www\Questionnaire\resources\views/components/nodata.blade.php ENDPATH**/ ?>