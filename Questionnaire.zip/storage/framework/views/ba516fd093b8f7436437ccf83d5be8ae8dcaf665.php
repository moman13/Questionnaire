<?php $attributes = $attributes->exceptProps([
    'name',
    'value',
    'title',
    'checked'=>false,
    'livewire'=>false
]); ?>
<?php foreach (array_filter(([
    'name',
    'value',
    'title',
    'checked'=>false,
    'livewire'=>false
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="flex items-start">
    <div class="absolute flex items-center h-5">
        <input id="candidates" <?php if($livewire): ?> wire:model.debounce.500ms="<?php echo $livewire; ?>" <?php endif; ?> <?php echo e($checked?'checked' : ''); ?> name="<?php echo e($name); ?>"  value="<?php echo e($value); ?>" type="checkbox" class="form-checkbox h-4 w-4 text-indigo-600 transition duration-150 ease-in-out">
    </div>
    <div class="pl-7 text-sm leading-5">
        <label for="candidates" class="font-medium text-gray-700"><?php echo e($title); ?></label>
    </div>
</div><?php /**PATH C:\wamp64\www\Questionnaire\resources\views/components/checkout.blade.php ENDPATH**/ ?>