<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php if (! empty(trim($__env->yieldContent('title')))): ?>

        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <?php else: ?>
        <title><?php echo e(config('app.name')); ?></title>
<?php endif; ?>

<!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url(asset('favicon.ico'))); ?>">
    <!-- Fonts -->
    <link rel="stylesheet" href="https://rsms.me/inter/inter.css">

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(url(mix('css/app.css'))); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://unpkg.com/filepond/dist/filepond.css" rel="stylesheet">
</head>

<body>

<div class="h-screen flex overflow-hidden bg-gray-100" x-data="{ sidebarOpen: false }" @keydown.window.escape="sidebarOpen = false">
    <?php echo $__env->make('admin_layout.side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="flex flex-col w-0 flex-1 overflow-auto">
        <div class="md:hidden pl-1 pt-1 sm:pl-3 sm:pt-3">
            <button @click.stop="sidebarOpen = true" class="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-900 focus:outline-none focus:bg-gray-200 transition ease-in-out duration-150">
                <svg class="h-6 w-6" stroke="currentColor" fill="none" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
        <div id="app">
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.notification','data' => []]); ?>
<?php $component->withName('notification'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
            <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('notification', [])->dom;
} elseif ($_instance->childHasBeenRendered('jNcrwz4')) {
    $componentId = $_instance->getRenderedChildComponentId('jNcrwz4');
    $componentTag = $_instance->getRenderedChildComponentTagName('jNcrwz4');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jNcrwz4');
} else {
    $response = \Livewire\Livewire::mount('notification', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('jNcrwz4', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>

            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
    <?php
if (! isset($_instance)) {
    $dom = \Livewire\Livewire::mount('confirm-component', [])->dom;
} elseif ($_instance->childHasBeenRendered('DBTO5yn')) {
    $componentId = $_instance->getRenderedChildComponentId('DBTO5yn');
    $componentTag = $_instance->getRenderedChildComponentTagName('DBTO5yn');
    $dom = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DBTO5yn');
} else {
    $response = \Livewire\Livewire::mount('confirm-component', []);
    $dom = $response->dom;
    $_instance->logRenderedChild('DBTO5yn', $response->id, \Livewire\Livewire::getRootElementTagName($dom));
}
echo $dom;
?>
</div>

<script src="<?php echo e(url(mix('js/app.js'))); ?>"></script>
<?php echo \Livewire\Livewire::scripts(); ?>

<script src="https://unpkg.com/filepond/dist/filepond.js" ></script>

</body>
</html>
<?php /**PATH C:\wamp64\www\Questionnaire\resources\views/admin_layout/main.blade.php ENDPATH**/ ?>